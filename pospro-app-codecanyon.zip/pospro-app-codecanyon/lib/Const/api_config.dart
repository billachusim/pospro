class APIConfig {
  static String domain = 'https://pospro.acnoo.com/';
  static String url = 'https://pospro.acnoo.com/api/v1';
  static String registerUrl = '/sign-up';
  static String businessCategoriesUrl = '/business-categories';
}
