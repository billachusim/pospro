String currency = '৳';
String currencyName = 'Bangladeshi Taka';
List<String> items = ['৳ (Taka)', '\$ (US Dollar)', "₹ (Rupee)", "€ (Euro)", "₽ (Ruble)", "£ (UK Pound)", "R (Rial)", "؋ Af ⁄ Afs"];
